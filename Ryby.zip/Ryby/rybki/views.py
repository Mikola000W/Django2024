from rybki.models import Ryby, OkresOchronny
from django.shortcuts import render, get_object_or_404


def rybunie(request):
    ryb = Ryby.objects.all()
    och = OkresOchronny.objects.all()


    return render(request, "ryby.html", {"ryb":ryb,"och":och})

# def details(request, id):
#     prac = get_object_or_404(Pracownicy,pk=id)
#     stan = get_object_or_404(Stanowiska,pk=id)
#     return render(request, "detail.html",{"pracownik":prac,"stano":stan})
# Create your views here.
# Create your views here.
