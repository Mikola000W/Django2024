from django.apps import AppConfig


class RybkiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rybki'
