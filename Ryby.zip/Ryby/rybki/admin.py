from django.contrib import admin

from rybki.models import Ryby, OkresOchronny

admin.site.register(Ryby)
admin.site.register(OkresOchronny)
# Register your models here.
