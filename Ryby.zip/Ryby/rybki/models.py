from django.db import models

class Ryby(models.Model):
    Nazwa = models.CharField(max_length=200)
    Wystepowanie = models.CharField(max_length=50)
    Styl_zycie = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.Nazwa}"
    class Meta:
        verbose_name_plural = "Ryby"


class OkresOchronny(models.Model):
    Od_miesiaca = models.PositiveIntegerField()
    Do_miesiaca = models.PositiveIntegerField()
    Wymiar_ochronny = models.IntegerField()
    Ryby_id = models.ForeignKey(Ryby,on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.Od_miesiaca} {self.Do_miesiaca}"
    class Meta:
        verbose_name_plural = "Okres ochronny"
# Create your models here.
