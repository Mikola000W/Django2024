from django.shortcuts import render
from paliwo.models import Paliwo


def paliwko(request):
    pal = Paliwo.objects.all()

    return render(request, "index.html", {"a":Paliwo.objects.count(),"pal":pal})
# Create your views here.
