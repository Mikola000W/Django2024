from django.contrib import admin
from django.urls import path
from paliwo.views import paliwko

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', paliwko,name="paliwko"),

]
