from django.shortcuts import render, redirect
from PokojeApp.models import Pokoje,Rezerwacje
from django.forms import modelform_factory


def welcome(request):
    rezer = Rezerwacje.objects.all()
    return render(request, "index.html", { "rez":rezer})

reze = modelform_factory(Rezerwacje, exclude=[])

def rezerwacja(request):
    if request.method=="POST":
        form=reze(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")
    else:
        form=reze()
    return render(request, "rezerwacja.html",{"form": form})
# Create your views here.
