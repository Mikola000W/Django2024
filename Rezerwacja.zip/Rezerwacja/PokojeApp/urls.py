from django.contrib import admin
from django.urls import path
from PokojeApp.views import welcome, rezerwacja

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', welcome, name="welcome"),
    path('rez', rezerwacja, name="rezerwacja"),

]