from django.db import models


class Pokoje(models.Model):
    nazwa = models.CharField(max_length=50)
    cena = models.IntegerField()

    def __str__(self):
        return f"{self.nazwa} {self.cena}"

    class Meta:
        verbose_name_plural = "Pokoje"

class Rezerwacje(models.Model):
    liczba_dni = models.IntegerField()
    sezon = models.CharField(max_length=50)
    id_pokoju = models.ForeignKey(Pokoje, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.sezon} {self.id_pokoju} {self.liczba_dni}"

    class Meta:
        verbose_name_plural = "Rezerwacje"

# Create your models here.
