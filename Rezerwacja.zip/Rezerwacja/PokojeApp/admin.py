from django.contrib import admin
from PokojeApp.models import Pokoje, Rezerwacje

admin.site.register(Pokoje)
admin.site.register(Rezerwacje)

# Register your models here.
