from django.apps import AppConfig


class PokojeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PokojeApp'
