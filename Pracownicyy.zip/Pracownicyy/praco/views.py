from django.shortcuts import render
from models import Stanowiska,Pracownicy
# Create your views here.

def welcome (request):
    prac = Pracownicy.objects.all()
    return render(request, "index.html", {"a": Pracownicy.objects.count(),"praco":prac})
