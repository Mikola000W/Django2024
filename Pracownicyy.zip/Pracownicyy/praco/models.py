from django.db import models


class Stanowiska(models.Model):
    nazwa = models.CharField(max_length=150)
    opis = models.CharField(max_length=250)

    def __str__(self):
        return f"{self.nazwa}"
    class Meta:
        verbose_name_plural = "Stanowiska"
# Create your models here.

class Pracownicy(models.Model):
    imie = models.CharField(max_length=50)
    nazwisko = models.CharField(max_length=100)
    adres = models.CharField(max_length=200)
    miasto = models.CharField(max_length=100)
    czyRodo = models.PositiveIntegerField()
    czyBadania = models.PositiveIntegerField()
    dataUr = models.DateField()
    stanowiska_id = models.ForeignKey(Stanowiska, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.imie}"
    class Meta:
        verbose_name_plural = "Pracownicy"