from django.contrib import admin

from praco.models import Stanowiska, Pracownicy

admin.site.register(Stanowiska)
admin.site.register(Pracownicy)
# Register your models here.
